class Alumno():
     def __init__(self, nombre, nota):
      self.nombre = nombre
      self.nota = nota

     def __str__(self):
         return "nombre: {} nota: {}".format( self.nombre, self.nota )
alumno = Alumno("pepe", 6)
print(alumno)
if 6 > 5:
     print("estas aprobado")
else:
     print("estas suspendido")

