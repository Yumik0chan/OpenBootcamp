class vehiculo():
     color = None
     ruedas = 4
     puertas = 4

class Coche(vehiculo):
     velocidad = 200
     cilindrada  = 2500

c = Coche()
c.color = "Rojo"
print("el coche es:", c.color)

