def primo():
  numero: int = int(input('Introduce un número entero: '))

  if numero > 1:
    # Buscamos los factores de número
    for i in range(2,int(numero)):
        if (int(numero) % i) == 0:
            print(f"el número {numero} no es primo. Es divisible entre {i}")
            break
        else:
            print(f"el número {numero} es primo")
            break
  else:
    print(f"Lo siento, el número {numero} no es primo. Los números primos son mayores que 1")

print({primo()})

