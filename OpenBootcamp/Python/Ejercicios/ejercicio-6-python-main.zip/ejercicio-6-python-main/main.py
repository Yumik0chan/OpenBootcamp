def area(a, b):
   print("El area del triangulo es de:",a*b/2,"cm2")
area(20, 14)

def areac(a):
    print("el area del circulo es de", 3.14*a**2,"cm2")
areac(7)

