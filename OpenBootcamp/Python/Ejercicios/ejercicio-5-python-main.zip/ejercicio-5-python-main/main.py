lista = []
for i in range(0, 101):
    lista.append(i)
lista.reverse()
print(lista)

