for numero in range(2, 8):
    if numero %2 != 0:
        print("el", numero, "es impar")
        
        
