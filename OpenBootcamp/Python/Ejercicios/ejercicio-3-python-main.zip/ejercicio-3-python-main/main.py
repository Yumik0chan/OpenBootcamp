edad = input()
int(edad)

if int(edad) >= 18:
    print("eres mayor de edad")
else:
    print("no eres mayor de edad")
    
    
    
