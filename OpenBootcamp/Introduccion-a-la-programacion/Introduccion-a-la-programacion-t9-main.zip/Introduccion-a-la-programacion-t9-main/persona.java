public class persona {

 int edad;
 String nombre;
 int telefono;

  public static void main(String[] args) {
    Cliente cliente = new Cliente();
    cliente.nombre = "Pablo";
    cliente.credito = 1000;
    cliente.edad = 20;
    cliente.telefono = 6000000;
    System.out.println(cliente.nombre);
    System.out.println(cliente.edad);
    System.out.println(cliente.telefono);
    System.out.println(cliente.credito);
    Trabajador trabajador = new Trabajador();
    trabajador.nombre = "manuel";
    trabajador.edad = 39;
    trabajador.telefono = 6000009;
    trabajador.salario = 100000;
    System.out.println(trabajador.nombre);
    System.out.println(trabajador.edad);
    System.out.println(trabajador.telefono);
    System.out.println(trabajador.salario);
  }
}

class Cliente extends persona {
    int credito;
}

class Trabajador extends persona{
    int salario;
}
